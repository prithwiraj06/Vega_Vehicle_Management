namespace vega.Controllers
{
    public static class Policies
    {
        public const string RequireAdminRole = "RequireAdminRole";
    }
}